package com.example.myapplication;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class Activity1 extends AppCompatActivity {
    boolean redance (int l ) {
      String   s=String.valueOf(l);
        int k = 0;
        do {
            for (int i = 0; i < s.length(); i++) {
                if ( s.charAt(i) == s.charAt(k) && (i != k)) {
                    return false;
                }

            }
            k++;
        }
        while (k<s.length());
        return true ;
    }
TextView big,mot;
Button btn,effacer,Re,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn0;
ImageView image ;
public void ground(int n) {
    switch (n) {
        case 0 :btn0.setBackgroundResource(R.drawable.round_button)  ;btn0.setEnabled(true);
            btn0.setClickable(true);break ;
        case 1 :btn1.setBackgroundResource(R.drawable.round_button) ; btn1.setEnabled(true);
            btn1.setClickable(true); break;
        case 2 :btn2.setBackgroundResource(R.drawable.round_button) ;btn2.setEnabled(true);
            btn2.setClickable(true); break;
        case 3 :btn3.setBackgroundResource(R.drawable.round_button) ;btn3.setEnabled(true);
            btn3.setClickable(true); break;
        case 4 :btn4.setBackgroundResource(R.drawable.round_button) ;btn4.setEnabled(true);
            btn4.setClickable(true); break;
        case 5 :btn5.setBackgroundResource(R.drawable.round_button) ;btn5.setEnabled(true);
            btn5.setClickable(true); break;
        case 6 :btn6.setBackgroundResource(R.drawable.round_button) ;btn6.setEnabled(true);
            btn6.setClickable(true); break;
        case 7 :btn7.setBackgroundResource(R.drawable.round_button) ;btn7.setEnabled(true);
            btn7.setClickable(true); break;
        case 8 :btn8.setBackgroundResource(R.drawable.round_button) ;btn8.setEnabled(true);
            btn8.setClickable(true); break;
        case 9 :btn9.setBackgroundResource(R.drawable.round_button) ;btn9.setEnabled(true);
            btn9.setClickable(true); break;


    }
}
 public void Color  (boolean  r) {
     if (r) {
         btn0.setEnabled(true);
         btn0.setClickable(true);
         btn1.setEnabled(true);
         btn1.setClickable(true);
         btn2.setEnabled(true);
         btn2.setClickable(true);
         btn3.setEnabled(true);
         btn3.setClickable(true);
         btn4.setEnabled(true);
         btn4.setClickable(true);
         btn5.setEnabled(true);
         btn5.setClickable(true);
         btn6.setEnabled(true);
         btn6.setClickable(true);
         btn7.setEnabled(true);
         btn7.setClickable(true);
         btn8.setEnabled(true);
         btn8.setClickable(true);
         btn9.setEnabled(true);
         btn9.setClickable(true);
         btn0.setBackgroundResource(R.drawable.round_button);
         btn1.setBackgroundResource(R.drawable.round_button);
         btn2.setBackgroundResource(R.drawable.round_button);
         btn3.setBackgroundResource(R.drawable.round_button);
         btn4.setBackgroundResource(R.drawable.round_button);
         btn5.setBackgroundResource(R.drawable.round_button);
         btn6.setBackgroundResource(R.drawable.round_button);
         btn7.setBackgroundResource(R.drawable.round_button);
         btn8.setBackgroundResource(R.drawable.round_button);
         btn9.setBackgroundResource(R.drawable.round_button);


     }

 }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
 int nb ;
        super.onCreate(savedInstanceState);

        do {
            Random random = new Random();
             nb = 1000+random.nextInt(9999-1000);


        }
        while (redance(nb)==false);
        final String Devine = String.valueOf(nb);
        setContentView(R.layout.activity_1);
        effacer=findViewById(R.id.effacer);
        Re=findViewById(R.id.Re);
        big=findViewById(R.id.big1);
        mot = findViewById(R.id.mot);
        btn = findViewById(R.id.btn);
        btn0 = findViewById(R.id.btn0);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.bnt2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);
        image = (ImageView) findViewById(R.id.image1);

        effacer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mot.length()>0) {

                    String k =mot.getText().toString().substring(mot.length()-1,mot.length());
                    ground(Integer.valueOf(k));
                    String ef = mot.getText().toString().substring(0, mot.length() - 1);
                    mot.setText(ef);
                }
                else Toast.makeText(Activity1.this, "Number Vide", Toast.LENGTH_SHORT).show();
            }
        });
        btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mot.length() == 0) {
                    Toast.makeText(Activity1.this, "Le nombre ne commence pas par 0", Toast.LENGTH_SHORT).show();
                 }
                else if(mot.length()==4)  {
                    Toast.makeText(Activity1.this, "nombre de 4", Toast.LENGTH_SHORT).show();

                }


                else {
                    mot.setText(mot.getText() + "0");
                    btn0.setEnabled(false);
                    btn0.setClickable(false);
                    btn0.setBackgroundResource(R.drawable.costume_button);
                }
            }});
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mot.length()==4)  {
                    Toast.makeText(Activity1.this, "nombre de 4", Toast.LENGTH_SHORT).show();

                }

                else {
                mot.setText(mot.getText()+"1");
                btn1.setEnabled(false);
                btn1.setClickable(false);
                btn1.setBackgroundResource(R.drawable.costume_button);
            }}
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(mot.length()==4)  {
                    Toast.makeText(Activity1.this, "nombre de 4", Toast.LENGTH_SHORT).show();

                }

                else
                {
                    mot.setText(mot.getText() + "2");

                    btn2.setEnabled(false);
                    btn2.setClickable(false);
                    btn2.setBackgroundResource(R.drawable.costume_button);
                }
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mot.length()==4)  {
                    Toast.makeText(Activity1.this, "Nombre de 4", Toast.LENGTH_SHORT).show();

                }

                else
                {
                mot.setText(mot.getText()+"3");
                btn3.setEnabled(false);
                btn3.setClickable(false);
                btn3.setBackgroundResource(R.drawable.costume_button);
            }}
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mot.length()==4)  {
                    Toast.makeText(Activity1.this, "nombre de 4", Toast.LENGTH_SHORT).show();

                }

                else
                {
                mot.setText(mot.getText()+"4");
                btn4.setEnabled(false);
                btn4.setClickable(false);
                btn4.setBackgroundResource(R.drawable.costume_button);
            }}
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mot.length()==4)  {
                    Toast.makeText(Activity1.this, "nombre de 4", Toast.LENGTH_SHORT).show();

                }

                else
                {
                mot.setText(mot.getText()+"5");
                btn5.setEnabled(false);
                btn5.setClickable(false);
                btn5.setBackgroundResource(R.drawable.costume_button);
            }}
        });
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mot.length()==4)  {
                    Toast.makeText(Activity1.this, "nombre de 4", Toast.LENGTH_SHORT).show();

                }

                else
                {
                mot.setText(mot.getText()+"6");
                btn6.setEnabled(false);
                btn6.setClickable(false);
                btn6.setBackgroundResource(R.drawable.costume_button);
            }}
        });
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mot.length()==4)  {
                    Toast.makeText(Activity1.this, "nombre de 4", Toast.LENGTH_SHORT).show();

                }

                else
                {
                mot.setText(mot.getText()+"7");
                btn7.setEnabled(false);
                btn7.setClickable(false);
                btn7.setBackgroundResource(R.drawable.costume_button);
            }}
        });
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mot.length()==4)  {
                    Toast.makeText(Activity1.this, "nombre de 4", Toast.LENGTH_SHORT).show();

                }

                else {
                    mot.setText(mot.getText() + "8");
                    btn8.setEnabled(false);
                    btn8.setClickable(false);
                    btn8.setBackgroundColor(Color.parseColor("#191970"));
                    btn8.setBackgroundResource(R.drawable.costume_button);
                }
            }
        }); btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mot.length()==4)  {
                    Toast.makeText(Activity1.this, "nombre de 4", Toast.LENGTH_SHORT).show();

                }

                else {
                    mot.setText(mot.getText() + "9");
                    btn9.setEnabled(false);
                    btn9.setClickable(false);
                    btn9.setBackgroundColor(Color.parseColor("#191970"));
                    btn9.setBackgroundResource(R.drawable.costume_button);
                }
            }
        });


        btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                int V = 0;
                int T = 0;
                String mote = String.valueOf(mot.getText());
                if (mote.length()<4) {
                    Toast.makeText(Activity1.this, "Number4", Toast.LENGTH_SHORT).show();
                }
                else {
                    for (int i=0;i<Devine.length();i++) {
                        for (int k = 0; k < mote.length(); k++) {
                          if (Devine.charAt(i)==mote.charAt(k)) {
                              if (k==i) {
                               T++;
                              }
                              else V++ ;
                          }
                        }
                    }
                    big.setText(big.getText() + "\n" + mote+" "+V+"V"+" "+T+"T"   );
                    mot.setText("");
                        Color(true);

                       

                }

            }
        });

Re.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {

        Intent intent = new Intent(Activity1.this,Activity1.class);
        startActivity(intent);
    }
});


    }

}
